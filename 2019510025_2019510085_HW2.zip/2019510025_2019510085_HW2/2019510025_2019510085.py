import json
import operator
import csv
from pickle import NONE


filename='students.csv'
stu_dic={} #student dictionary
dic1={}
with open(filename,'r') as csvfile:
    csvreader=csv.reader(csvfile)
    i=1
    for column in csvreader:
       x=column[0].split(";",5)
       if (i==1):
        dic1[x[0]]= x[1],x[2],x[3],x[4]
        i=i+1
       else:
        stu_dic[int(x[0])]= x[1],x[2],x[3],int(x[4]) 
        
def sort(dic,i):
    if(i==0): #ASC
      sorted_dic= dict(sorted(dic.items(),key=operator.itemgetter(0)))
    elif(i==1): #DSC
      sorted_dic= dict(sorted(dic.items(),key=operator.itemgetter(0),reverse=True))
    return sorted_dic

dic_array=[15]
index=0
sorted_dic=sort(stu_dic,1)
ops = { "=": operator.eq, "!=": operator.ne, "<": operator.lt ,
       ">": operator.gt,  "<=":operator.le ,">=": operator.ge,"!<": operator.ge ,"!>":operator.le}
  

def selectitem_in_dict(sorted_dic,condition):
    select_dic={ }
    name=False
    surname=False
    email=False
    grade=False
    id=False
    if(condition[0]=="name"):
      name=True
    if(condition[0]=="surname"):
      surname=True
    if(condition[0]=="email"):  
      email=True
    if(condition[0]=="grade"):   
      grade=True
    if(condition[0]=="id"):   
      id=True
    for i in sorted_dic.copy():
        if(name and ops[condition[1]](sorted_dic[i][0].lower(),condition[2])): 
          select_dic[i]=sorted_dic[i]
        elif(surname and ops[condition[1]](sorted_dic[i][1].lower(),condition[2])):
          select_dic[i]=sorted_dic[i]
        elif(email and ops[condition[1]](sorted_dic[i][2].lower(),condition[2])):
          select_dic[i]=sorted_dic[i]
        elif(grade and ops[condition[1]](int(sorted_dic[i][3]),int(condition[2]))):
          select_dic[i]=sorted_dic[i]
        elif(id and ops[condition[1]](i,int(condition[2]))):
          select_dic[i]=sorted_dic[i]
    return  select_dic     
 

def select(sorted_dic,condition_mode,sort_mode,condition,conditions,):
 
  select_dic={ }
  flag=True
  if(condition_mode=="one condition"): 
   if(condition[0]=="name" or condition[0]=="lastname" or condition[0]=="email"):
    if(condition[1]=="<" or condition[1]==">" or condition[1]=="<=" or condition[1]==">=" or condition[1]=="!<" or condition[1]=="<!"):
      flag=False
      print("incorrect operand")
  if(condition_mode=="second condition"):
    if(conditions[0]=="name" or conditions[0]=="lastname" or conditions[0]=="email"):
      if(conditions[1]=="<" or conditions[1]==">" or conditions[1]=="<=" or conditions[1]==">=" or conditions[1]=="!<" or conditions[1]=="<!"):
        flag=False
        print("incorrect operand")
    if(conditions[4]=="name" or conditions[4]=="lastname" or conditions[4]=="email"):
      if(conditions[5]=="<" or conditions[5]==">" or conditions[5]=="<=" or conditions[5]==">=" or conditions[5]=="!<" or conditions[5]=="<!"):
        flag=False
        print("incorrect operand")      
  if(flag):
    if(condition_mode=="one condition"):
      select_dic=selectitem_in_dict(sorted_dic,condition)        
    elif(condition_mode=="two condition"):
      name=False
      surname=False
      email=False
      grade=False
      id=False
      if(conditions[0]=="name"):
        name=True
      if(conditions[0]=="surname"):
        surname=True
      if(conditions[0]=="email"):  
        email=True
      if(conditions[0]=="grade"):
        grade=True
      if(conditions[0]=="id"):
        id=True
        
      name1=False
      surname1=False
      email1=False
      grade1=False
      id1=False
      if(conditions[4]=="name"):
        name1=True
      if(conditions[4]=="surname"):
        surname1=True
      if(conditions[4]=="email"):  
        email1=True
      if(conditions[4]=="grade"):
        grade1=True
      if(conditions[4]=="id"):
        id1=True  
      if(conditions[3].lower()=="and"):
        condition=conditions[0],conditions[1],conditions[2]
        first_condition_dic=selectitem_in_dict(sorted_dic,condition)
        condition=conditions[4],conditions[5],conditions[6]
        select_dic=selectitem_in_dict(first_condition_dic,condition) 
      elif(conditions[3]=="or"):
        flag=False
        for i in sorted_dic.copy():
            if(name and ops[conditions[1]](sorted_dic[i][0].lower(),conditions[2])): 
              flag=True
            elif(surname and ops[conditions[1]](sorted_dic[i][1].lower(),conditions[2])):
              flag=True
            elif(email and ops[conditions[1]](sorted_dic[i][2].lower(),conditions[2])):
              flag=True
            elif(grade and ops[conditions[1]](int(sorted_dic[i][3]),int(conditions[2]))):  
              flag=True
            elif(id and ops[conditions[1]](i,int(conditions[2]))):
              flag=True
            
            if(name1 and ops[conditions[5]](sorted_dic[i][0].lower(),conditions[6])): 
              flag=True
            elif(surname1 and ops[conditions[5]](sorted_dic[i][1].lower(),conditions[6])):
              flag=True
            elif(email1 and ops[conditions[5]](sorted_dic[i][2].lower(),conditions[6])):
              flag=True
            elif(grade1 and ops[conditions[5]](int(sorted_dic[i][3]),int(conditions[6]))):
              flag=True
            elif(id1 and ops[conditions[5]](i,int(conditions[6]))):
              flag=True 
            if(flag):
              select_dic[i]=sorted_dic[i]
              flag=False
    if(sort_mode=="asc"):
      select_dic=sort(select_dic,0)
    elif(sort_mode=="dsc"):
      select_dic=sort(select_dic,1)                  
  return select_dic
while(True):
    print("-->SQL Query")
    queryInput=input()
    select_dic={ }
    if(queryInput=="exit"):
          break
    else:
      parts_of_query=queryInput.split(" ")
      if ( parts_of_query[0].lower()=="select" and parts_of_query[2].lower()=="from" and parts_of_query[3].lower()=="students"and parts_of_query[4].lower()=="where") :
        condition_mode=" "
        sort_mode=""
        column_name=""
        condition =[]
        conditions =[]
        #one condition
        if(parts_of_query[8].lower()=="order" and parts_of_query[9].lower()=="by"):
          condition_mode="one condition"
          if(parts_of_query[9].lower()=="asc"):
            sort_mode="asc"
          elif(parts_of_query[9].lower()=="dsc"):
            sort_mode="dsc"
          condition=parts_of_query[5].lower(),parts_of_query[6].lower(),parts_of_query[7].lower()
          select_dic=select(sorted_dic,condition_mode,sort_mode,condition,conditions)       
        #two condition             
        elif(parts_of_query[12].lower()=="order" and parts_of_query[13].lower()=="by"):
          if(parts_of_query[14].lower()=="asc"):
            sort_mode="asc"
          elif(parts_of_query[14].lower()=="dsc"):
            sort_mode="dsc"
          condition_mode="two condition"
          conditions=parts_of_query[5].lower(),parts_of_query[6].lower(),parts_of_query[7].lower(),parts_of_query[8].lower(),parts_of_query[9].lower(),parts_of_query[10].lower(),parts_of_query[11].lower()
          select_dic=select(sorted_dic,condition_mode,sort_mode,condition,conditions)
        else:
          print("This is an incorrect query.")
        if(parts_of_query[1].lower()=="*"):#for writing a json file
          print("all")
        else:
          column_names=parts_of_query[1].split(",")
          if(  len(column_names)>5):
            print("This is an incorrect column names.")
      elif(parts_of_query[0].lower()=="insert" and parts_of_query[1].lower()=="into" and parts_of_query[2].lower()=="student"):
        parts1=parts_of_query[3].split("(")
        parts2=parts1[1].split(")")
        parts3=parts2[0].split(",")
        sorted_dic[int(parts3[0])]=parts3[1],parts3[2],parts3[3],int(parts3[4])
      elif(parts_of_query[0].lower()=="delete" and parts_of_query[1].lower()=="from" and parts_of_query[2].lower()=="student" and parts_of_query[3].lower()=="where"):
        if(len(parts_of_query)==7):#one condition
          name=False
          surname=False
          email=False
          grade=False
          id=False
          if(parts_of_query[4]=="name"):
            name=True
          if(parts_of_query[4]=="surname"):
            surname=True
          if(parts_of_query[4]=="email"):  
            email=True
          if(parts_of_query[4]=="grade"):   
            grade=True
          if(parts_of_query[4]=="id"):   
            id=True
          for i in sorted_dic.copy():
              if(name and ops[parts_of_query[5]](sorted_dic[i][0].lower(),parts_of_query[6])): 
                sorted_dic.pop(i,NONE)
              elif(surname and ops[parts_of_query[5]](sorted_dic[i][1].lower(),parts_of_query[6])):
                sorted_dic.pop(i,NONE)
              elif(email and ops[parts_of_query[5]](sorted_dic[i][2].lower(),parts_of_query[6])):
                sorted_dic.pop(i,NONE)
              elif(grade and ops[parts_of_query[5]](int(sorted_dic[i][3]),int(parts_of_query[6]))):
                sorted_dic.pop(i,NONE)
              elif(id and ops[parts_of_query[5]](i,int(parts_of_query[6]))):
                sorted_dic.pop(i,NONE)       
        elif(len(parts_of_query)==11):#two condition
          conditions=parts_of_query[4].lower(),parts_of_query[5].lower(),parts_of_query[6].lower(),parts_of_query[7].lower(),parts_of_query[8].lower(),parts_of_query[9].lower(),parts_of_query[10].lower()
          remove_dic=select(sorted_dic,"two condition"," "," ",conditions)
          for i in remove_dic.copy():
            if(sorted_dic[i]==remove_dic[i]):
               sorted_dic.pop(i,NONE)
        else:
          print("Incorrect query !!")   
      else:
        print("Incorrect query !!")    
with open('json_data.json', 'w') as json_data_file:
  json.dump(dic_array[i],json_data_file,allow_nan=False,sort_keys=True,indent=4,ensure_ascii=False)   