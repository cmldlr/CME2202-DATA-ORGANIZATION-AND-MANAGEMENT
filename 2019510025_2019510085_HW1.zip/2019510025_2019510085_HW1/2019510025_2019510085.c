#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// struct for records
typedef struct {
 char name[64];   //utf-16
 char surname[32];  //utf-8
 char gender;
 char email[32];
 char phone_number[16];
 char address[32];
 char level_of_education[8];
 unsigned int income_level; // given little-endian
 unsigned int expenditure; // given big-endian
 char currency_unit[16];
 char currentMood[32];
 float height;
 unsigned int weight;
}record;

// taken from https://stackoverflow.com/questions/19275955/convert-little-endian-to-big-endian/19276193
// converts little to big and big to little endian
unsigned int switchEndian(unsigned int num) {
    return (((num >> 24) & 0x000000ff) | ((num << 8) & 0x00ff0000) | ((num >> 8) & 0x0000ff00) | ((num << 24) & 0xff000000));
}

// writes record to the xml file
void writeToXML(FILE *xmlFile, record record, int id){
    unsigned int bigIL = switchEndian(record.income_level); // big endian form of income level
    unsigned int littleExp = switchEndian(record.expenditure); // little endian form of expenditure

    fprintf(xmlFile, "\t<row id=\"%d\">\n", id);
    fprintf(xmlFile, "\t\t<%s>%s</%s>\n", "name", record.name, "name");
    fprintf(xmlFile, "\t\t<%s>%s</%s>\n", "surname", record.surname,"surname");
    fprintf(xmlFile, "\t\t<%s>%c</%s>\n", "gender", record.gender, "gender");
    fprintf(xmlFile, "\t\t<%s>%s</%s>\n", "email", record.email,"email");
    fprintf(xmlFile, "\t\t<%s>%s</%s>\n", "phone_number", record.phone_number,"phone_number");
    fprintf(xmlFile, "\t\t<%s>%s</%s>\n", "address", record.address,"address");
    fprintf(xmlFile, "\t\t<%s>%s</%s>\n", "level_of_education", record.level_of_education, "level_of_education");
    //fprintf(xmlFile, "\t\t<%s bigEnd=\"%u\">%u</%s>\n", "income_level", bigIL, rec.income_level, "income_level");
    //fprintf(xmlFile, "\t\t<%s bigEnd=\"%u\">%u</%s>\n", "expenditure", rec.expenditure, littleExp, "expenditure");
    fprintf(xmlFile, "\t\t<%s>%s</%s>\n", "currency_unit", record.currency_unit,"currency_unit");
    fprintf(xmlFile, "\t\t<%s>%s</%s>\n", "currentMood", record.currentMood, "currentMood");
    fprintf(xmlFile, "\t\t<%s>%.2f</%s>\n", "height", record.height, "height");
    fprintf(xmlFile, "\t\t<%s>%u</%s>\n", "weight", record.weight, "weight");
    fprintf(xmlFile, "\t</row>\n");
}

void main(int argc, char *argv[]){

    if (argc != 3){ 
        puts("More or less than 3 arguments entered!\n");
        exit(1);
    }
    if(strcmp(argv[0], "./Bin2XML") != 0 && strcmp(argv[0], ".//Bin2XML") && strcmp(argv[0], "Bin2XML") != 0){
        puts("Wrong argument! Use argument Bin2XML to run.\n");
        exit(1);
    }

    FILE *binaryfile; 
    binaryfile = fopen(argv[1], "rb"); 
    if (binaryfile == NULL){
        puts("Error, File not found!\n");
        exit(1);
    } 
    record r;
    fread(&r, sizeof(r), 1, binaryfile); 
    FILE *xmlfile = fopen(argv[2], "w"); 
    fprintf(xmlfile, "<records>\n");
    record record; 
    int id = 1;
    while (1){ 
        fread(&record, sizeof(record), 1, binaryfile);
        if (strcmp(record.name, "") == 0){
            break;
        }
        writeToXML(xmlfile,record, id);
        id++; // increase id
    }
    fprintf(xmlfile, "</records>\n");

    // close the files
    fclose(binaryfile);
    fclose(xmlfile);

    puts("XML created successfully...");

}
