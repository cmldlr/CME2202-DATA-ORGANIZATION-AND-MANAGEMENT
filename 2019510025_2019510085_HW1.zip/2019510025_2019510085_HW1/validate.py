from pickle import TRUE
from lxml import etree
from io import StringIO

doc = etree.parse('records.xml')
root = doc.getroot()
#print(etree.tostring(root))
xmlschema_doc = etree.parse('records.xsd')
xmlschema = etree.XMLSchema(xmlschema_doc)
#doc = etree.XML(etree.tostring(root))
validation_result = xmlschema.validate(doc)
if(validation_result):
    print("Validation Completed.")
else:
    print("Validation Error.") 
xmlschema.assert_(doc)